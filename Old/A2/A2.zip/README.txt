
 * Using instructor provided list implementation (list.h, list.o)
 * Incoming messages interleave with what you are typing on terminal. Still, sending the message processes what you typed correctly.