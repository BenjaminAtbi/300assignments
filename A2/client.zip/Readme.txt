Some UDP socket code referenced from Beej's Guide to Network Programming
- http://beej.us/guide/bgnet/html/#datagram

addresses must be less than ADDRLENGTH in length (255 chars)

Receiving a message while typing will move cursor to next line, however the disjointed text from 
previous line will still count towards next message.

messages of length greater than MSGLENGTH-1 are split into multiple messages